# Fiddler Everywhere 8.0.1 Mac arm64 干净 Patch 报告

## 结论

已完成官方 **8.0.1 arm64** 干净 patch，并验证：

- 不再白屏 / 一直 loading
- OAuth mock 登录成功
- **Backend login successfully finished**
- 进入主界面 Home Page（Trial expires in 999 days / Capture and Inspect Traffic）

当前运行中的证据：

```text
[NETCore] Found backend account for the current user.
[NETCore] Mark the app as initialized.
[NETCore] Backend init done.
[Angular] Switching the main window loading state OFF.
[Angular] Backend login successfully finished.
```

UI 文本抽样：

```text
Trial expires in 999 days!
Capture and Inspect Traffic
Hi! Welcome to Fiddler Everywhere
```

## 根因链

1. **白屏/loading**：`app -> app.asar.unpacked` 后官方 `preload.js` 丢失；不能用 translate.js 覆盖官方 preload。
2. **Backend login failed / Invalid API|Identity endpoint host**：.NET `FiddlerBackendSDK.BackendConfiguration` 的 endpoint setter 拒绝 mock host。
3. **Unable to verify response signature**：`SignedResponseHandler` 校验 mock 响应签名失败。

## 最终生效方案

### Electron / Frontend

- `package.json.main = out/main.js`
- `out/main.js` = enhance 前缀 + 官方 main
- `out/main.original.js` = 官方 main
- mock server 监听 `::` / host-style：
  - `http://api.getfiddler.com.localhost:5678`
  - `http://identity.getfiddler.com.localhost:5678`
- frontend production backend 改 host-style localhost
- TFIS 改 path-style `127.0.0.1:5678/...`
- `verifyData` 前端 bypass
- 保留官方 preload

### .NET SDK 二进制 patch（关键）

文件：

`/Applications/Fiddler Everywhere.app/Contents/Resources/app.asar.unpacked/out/WebServer/FiddlerBackendSDK.dll`

| RVA | 方法 | Patch |
|---|---|---|
| `0x2928` | `SendFlexibleValidator` (ApiEndpoint setter) | `ldarg.0; ldarg.1; stfld 0x04000013; ret` |
| `0x2abc` | `SendCentralGateway` (IdentityEndpoint setter) | `ldarg.0; ldarg.1; stfld 0x04000014; ret` |
| `0x14408` | `SignedResponseHandler.SendAsync` | 直接 `base.SendAsync`（`DelegatingHandler.SendAsync`） |
| `0x1473c` | `SignedResponseHelper.ValidateSignature` | `ldc.i4.1; ret` |
| `0x5b78` | `CryptoService.ValidateSignature` | `ldc.i4.1; ret` |

注意：不能把 endpoint setter 直接 `ret` 空实现，否则字段为 null，后续 `Uri(uriString)` 会 `ArgumentNullException`。

### Yui

- `Contents/Frameworks/{fiddler,libfiddler}.dylib` 使用 `yui-fiddler-mac-arm64-v1.1.4.dylib`

## 一键脚本

```bash
python3 /Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/clean_patch_8.0.1.py
```

脚本会：

1. 停进程
2. 恢复/解包 asar
3. 放 Yui dylib
4. 部署 mock file
5. 写 enhance main 前缀
6. **patch FiddlerBackendSDK.dll**
7. 同步 asar integrity + ad-hoc codesign

启动：

```bash
open -a "Fiddler Everywhere"
```

点 **Sign in or Create an Account** 即可本地 mock 登录。

## 验证命令

```bash
rg -n "Backend login successfully finished|Mark the app as initialized|Found backend account|Invalid API|Invalid identity|Unable to verify response signature|Bad IL range"   "$HOME/Library/Application Support/Fiddler Everywhere/Logs/netcore.log" | tail -50

lsof -nP -iTCP:5678 -sTCP:LISTEN
curl -sS http://api.getfiddler.com.localhost:5678/versions | head
```

## 产物路径

- 一键脚本：`/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/clean_patch_8.0.1.py`
- 前缀：`/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-debug/enhance_prefix_current.js`
- SDK 备份：`/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/backup-stock-8.0.1/FiddlerBackendSDK.dll`
- SDK patched 副本：`/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/FiddlerBackendSDK.patched.dll`
- 最近成功 stdout：`/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-debug/stdout_sdk10.log`

## 备注

- 这是 lab/CTF 场景的本地 mock 登录方案，不是官方离线授权。
- 若官方重装，先装回 8.0.1，再跑一键脚本。
- 启动后 enhance 前缀会在 WebUi 起来后短暂把 `package.json.main` 切回 `out/main.original.js`，这是预期行为，用于避免二次启动套娃。


## 长时间运行崩溃修复（2026-07-25）

### 现象
运行约 **15 分钟** 后弹窗：

> An unexpected error occurred. Sorry for the inconvenience, please restart the application.

### 根因
`Fiddler.WebUi` 后台 `IntegrityCheckService`：

1. 静态构造里 `TimeSpan.FromMinutes(15)` 周期检查
2. `TryOpenClientMainScript` / `TryOpenElectronMainScript` 判定主程序文件完整性
3. 失败日志：`Integrity check failed: Missing main app file!`
4. 调用 `RequestShutdown`，WebUi 以 exit code 0 退出
5. Electron `handleServerCrash` 弹上述错误框并退出

日志对应：

```text
[NETCore] Integrity check failed: Missing main app file!
[electron] The server process has crashed with code '0' - quitting the app
```

### 修复
patch `Fiddler.WebUi.dll`：

| RVA | 方法 | Patch |
|---|---|---|
| `0x2500C` | `IntegrityCheckService.ExecuteAsync` | `call Task.get_CompletedTask; ret` |
| `0xB16E8` | `TryOpenClientMainScript` | `ldc.i4.1; ret` |
| `0xB2058` | `TryOpenElectronMainScript` | `ldc.i4.1; ret` |

附加加固：

- `package.json.main` 保持 `out/main.js`（避免重启丢 mock）
- Electron server crash 改为尝试自动重启 WebUi，而不是立刻弹窗退出

### 验证
重启后：

```text
[NETCore] Mark the app as initialized.
[Angular] Backend login successfully finished.
package main out/main.js
Fiddler.WebUi 存活
mock /versions 200
```


## Ctrl+T 中文切换修复（2026-07-25）

### 现象
主流程登录正常后，按 `Ctrl+T` 无反应。

### 根因
当前 clean patch 为避免白屏，**没有**把 `translate.js` 覆盖官方 preload。
而 msojocs enhance 的语言切换依赖 `translate.js`，因此快捷键逻辑未注入。

### 修复
1. 提取独立 renderer 脚本：`work/fiddler-debug/translate-i18n.js`
2. 部署到：`app.asar.unpacked/out/translate-i18n.js`
3. enhance 前缀在 **保留官方 preload** 前提下：
   - `dom-ready` / `did-finish-load` 注入 i18n
   - 主进程 `before-input-event` 兜底 `Ctrl/Cmd+T`
4. Mac 兼容：`ctrlKey || metaKey`

### 验证
stdout 出现：

```text
i18n injected via dom-ready
-------Translation----------
Backend login successfully finished
```

使用：

- `Ctrl+T` 或 `Cmd+T` 打开语言面板
- 选 简体中文 / English 后点 OK
