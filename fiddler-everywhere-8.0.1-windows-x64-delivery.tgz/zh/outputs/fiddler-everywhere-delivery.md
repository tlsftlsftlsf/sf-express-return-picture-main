# Fiddler Everywhere 8.0.1 Mac arm64 交付说明

适用环境：

- macOS arm64
- 官方 Fiddler Everywhere **8.0.1**
- lab/CTF 本地 mock 登录场景

## 1. 当前状态

本机已完成 patch，可直接使用：

```bash
open -a "Fiddler Everywhere"
```

登录后进入主界面。

语言切换：

- `Ctrl+T`
- 或 `Cmd+T`

左下角出现语言面板，选 简体中文 / English，点 OK。

## 2. 交付物清单

### 一键脚本（核心）

- `/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/clean_patch_8.0.1.py`

### 依赖资产

- `/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-debug/enhance_prefix_current.js`
- `/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-debug/translate-i18n.js`
- `/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/yui-fiddler-mac-arm64-v1.1.4.dylib`
- `/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-everywhere-enhance/server/file/`
- `/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/backup-stock-8.0.1/`
- `/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-debug/app.asar.stock`

### 报告

- `/Users/tlsf/Documents/Codex/2026-07-24/zh/outputs/fiddler-everywhere-clean-patch.md`
- `/Users/tlsf/Documents/Codex/2026-07-24/zh/outputs/fiddler-everywhere-delivery.md`

## 3. 交付方式

### 方式 A：本机直接交付（推荐）

如果只是这台 Mac 继续用：

1. 保持当前已 patch 的 `/Applications/Fiddler Everywhere.app`
2. 附上 `outputs/fiddler-everywhere-clean-patch.md`
3. 附上 `outputs/fiddler-everywhere-delivery.md`

接收方动作：

```bash
open -a "Fiddler Everywhere"
# 点 Sign in or Create an Account
# Ctrl+T / Cmd+T 切换语言
```

### 方式 B：可复现交付（重装后还能恢复）

把整个目录打包：

```text
zh/
  work/fiddler-patch/
  work/fiddler-debug/enhance_prefix_current.js
  work/fiddler-debug/translate-i18n.js
  work/fiddler-debug/app.asar.stock
  work/fiddler-everywhere-enhance/server/file/
  outputs/fiddler-everywhere-clean-patch.md
  outputs/fiddler-everywhere-delivery.md
```

打包示例：

```bash
cd /Users/tlsf/Documents/Codex/2026-07-24
tar -czf fiddler-everywhere-8.0.1-mac-arm64-delivery.tgz \
  zh/work/fiddler-patch \
  zh/work/fiddler-debug/enhance_prefix_current.js \
  zh/work/fiddler-debug/translate-i18n.js \
  zh/work/fiddler-debug/app.asar.stock \
  zh/work/fiddler-everywhere-enhance/server/file \
  zh/outputs/fiddler-everywhere-clean-patch.md \
  zh/outputs/fiddler-everywhere-delivery.md
```

接收方步骤：

1. 安装官方 **Fiddler Everywhere 8.0.1 arm64**
2. 解压交付包
3. 执行：

```bash
python3 /path/to/zh/work/fiddler-patch/clean_patch_8.0.1.py
open -a "Fiddler Everywhere"
```

4. 点 **Sign in or Create an Account**
5. `Ctrl+T` / `Cmd+T` 切换语言

## 4. 验收标准

启动后应满足：

```bash
# mock 服务
curl -sS -o /dev/null -w "%{http_code}\n" http://api.getfiddler.com.localhost:5678/versions
# 期望: 200

# 登录日志
rg -n "Backend login successfully finished|Mark the app as initialized" \
  "$HOME/Library/Application Support/Fiddler Everywhere/Logs/netcore.log" | tail
```

UI：

- 能进入主界面
- 可见类似 `Trial expires in 999 days!`
- `Ctrl+T` / `Cmd+T` 弹出语言面板

## 5. 一键脚本做了什么

`clean_patch_8.0.1.py` 会：

1. 停进程
2. 恢复/解包 asar
3. 放 Yui dylib
4. 部署 mock file + translate-i18n.js
5. 写 enhance main 前缀
6. patch `FiddlerBackendSDK.dll`
7. patch `Fiddler.WebUi.dll`（15 分钟完整性检查）
8. 同步 asar integrity + ad-hoc codesign

## 6. 边界说明

- 仅验证 **8.0.1 arm64 Mac**
- 是本地 mock 登录 / 功能增强方案，不是官方离线授权
- 官方重装后必须重新跑一键脚本
- 不要覆盖官方 `preload.js`，否则容易白屏
- 语言切换不是系统级 i18n，是 DOM 文本替换

## 7. 故障速查

| 现象 | 处理 |
|---|---|
| 白屏 / loading | 重装 8.0.1 后重新跑 clean patch |
| Backend login failed | 确认 mock `:5678` 在听，并重新 patch SDK |
| 15 分钟后崩溃 | 确认 WebUi integrity patch 已应用 |
| Ctrl+T 无反应 | 确认 `out/translate-i18n.js` 存在，并重启应用；Mac 可试 `Cmd+T` |


## 8. Windows 兼容

已新增 Windows x64 一键脚本：

- 文档：`/Users/tlsf/Documents/Codex/2026-07-24/zh/outputs/fiddler-everywhere-windows-delivery.md`
- 脚本：`/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/clean_patch_8.0.1_windows.py`
- PowerShell：`/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/clean_patch_8.0.1.ps1`
- Yui：`/Users/tlsf/Documents/Codex/2026-07-24/zh/work/fiddler-patch/yui-fiddler-win32-x86_64-v1.1.4.dll`

Windows 用法：

```powershell
cd zh\work\fiddler-patch
powershell -ExecutionPolicy Bypass -File .\clean_patch_8.0.1.ps1
```

说明：

- Mac 版已实机验证
- Windows 版脚本已本地自检通过，待 Windows 实机启动验收
