# Fiddler Everywhere 8.0.1 Windows x64 交付说明

适用环境：

- Windows x64
- 官方 Fiddler Everywhere **8.0.1**
- lab/CTF 本地 mock 登录场景

## 1. 结论

已补齐 **Windows 兼容一键 patch**，逻辑与已验证的 Mac 8.0.1 方案对齐：

- Yui `fiddler.dll` / `libfiddler.dll`
- enhance main 前缀 + 本地 mock backend
- frontend 改 host-style mock endpoint
- `FiddlerBackendSDK.dll` 签名/host 校验 bypass
- `Fiddler.WebUi.dll` 15 分钟完整性检查 bypass
- 中文切换：`Ctrl+T`（不覆盖官方 preload）

本机已做 **假目录自检通过**；真实 Windows 实机启动需在 Windows 上验收。

## 2. 交付物

### 脚本

- `zh/work/fiddler-patch/clean_patch_8.0.1_windows.py`
- `zh/work/fiddler-patch/clean_patch_8.0.1.ps1`

### 依赖

- `zh/work/fiddler-patch/yui-fiddler-win32-x86_64-v1.1.4.dll`
- `zh/work/fiddler-debug/enhance_prefix_current.js`
- `zh/work/fiddler-debug/translate-i18n.js`
- `zh/work/fiddler-debug/frontend_stock_restored.js`（frontend 回退库存）
- `zh/work/fiddler-patch/backup-stock-8.0.1/main.js`
- `zh/work/fiddler-patch/backup-stock-8.0.1/FiddlerBackendSDK.dll`
- `zh/work/fiddler-patch/backup-stock-8.0.1/Fiddler.WebUi.dll`
- `zh/work/fiddler-everywhere-enhance/server/file/`

### 文档

- `zh/outputs/fiddler-everywhere-windows-delivery.md`

## 3. Windows 安装与 patch

1. 安装官方 **Fiddler Everywhere 8.0.1 x64**
2. 解压交付包
3. 以管理员 PowerShell 进入目录并执行：

```powershell
cd <解压目录>\zh\work\fiddler-patch
powershell -ExecutionPolicy Bypass -File .\clean_patch_8.0.1.ps1
```

如果没自动找到安装目录：

```powershell
powershell -ExecutionPolicy Bypass -File .\clean_patch_8.0.1.ps1 -Root "C:\Users\<you>\AppData\Local\Programs\Fiddler Everywhere"
```

或：

```powershell
python .\clean_patch_8.0.1_windows.py --root "C:\Path\To\Fiddler Everywhere"
```

4. 启动 Fiddler Everywhere
5. 点 **Sign in or Create an Account**
6. 语言切换：`Ctrl+T`

## 4. 脚本会改什么

安装根目录（示例）：

`%LOCALAPPDATA%\Programs\Fiddler Everywhere`

关键文件：

| 路径 | 动作 |
|---|---|
| `fiddler.dll` / `libfiddler.dll` | 替换为 Yui |
| `resources\app.asar.unpacked\out\main.js` | enhance 前缀 + stock main |
| `resources\app.asar.unpacked\out\translate-i18n.js` | 中文切换脚本 |
| `resources\app.asar.unpacked\out\file\` | mock API 数据 |
| `...\WebServer\FiddlerBackendSDK.dll` | host/signature bypass |
| `...\WebServer\Fiddler.WebUi.dll` | integrity check bypass |
| `...\ClientApp\dist\main-*.js` | mock endpoint / verifyData bypass |
| `package.json` | `main = out/main.js` |

**不会**覆盖官方 `services/lib/preload.js`。

## 5. 验收

启动后：

```powershell
# mock
curl http://api.getfiddler.com.localhost:5678/versions

# 日志
# %USERPROFILE%\AppData\Roaming\Fiddler Everywhere\Logs\netcore.log
# 期望出现：
# Backend login successfully finished
# Mark the app as initialized
```

UI：

- 能进主界面
- 可见类似 `Trial expires in 999 days!`
- `Ctrl+T` 弹出语言面板

## 6. 与 Mac 差异

| 项 | Mac | Windows |
|---|---|---|
| 原生库 | `Contents/Frameworks/*.dylib` | 安装根目录 `fiddler.dll` |
| 路径 | `/Applications/Fiddler Everywhere.app` | `%LOCALAPPDATA%\Programs\Fiddler Everywhere` |
| 签名 | ad-hoc codesign | 无 codesign；可能需允许未知来源 DLL |
| 语言快捷键 | `Ctrl+T` / `Cmd+T` | `Ctrl+T` |
| 实机验证 | 已验证 | 脚本自检通过，待 Windows 实机验收 |

## 7. 故障速查

| 现象 | 处理 |
|---|---|
| 找不到安装目录 | 用 `-Root` / `--root` 指定 |
| 白屏 | 确认 `preload.js` 仍在；不要覆盖它；重装 8.0.1 再 patch |
| Backend login failed | 确认 5678 mock 启动；SDK patch 成功 |
| 15 分钟后退出 | 确认 WebUi integrity patch 成功 |
| Ctrl+T 无反应 | 确认 `out\translate-i18n.js` 存在并重启 |
| Windows Defender 删除 dll | 给安装目录加排除后重新 patch |

## 8. 边界

- 目标版本：**8.0.1 Windows x64**
- 是本地 mock / lab 方案，不是官方离线授权
- 若 Windows 8.0.1 前端/main 与 Mac 8.0.1 字节不完全一致，脚本会打印 WARN；那时需要按实机文件微调 pattern
