const port = 5678;
(() => {
  console.info('========== Fiddler-everywhere-enhance start ==========')
  const { app, BrowserWindow } = require('electron')
  const path = require('path')
  const fs = require('fs')
  const sp = require('child_process')
  const toWritable = (p) => String(p).replace(`${path.sep}app.asar${path.sep}`, `${path.sep}app.asar.unpacked${path.sep}`)
  const wdir = toWritable(__dirname)
  console.info('enhance wdir=', wdir, 'dirname=', __dirname)

  const frontendDir = path.resolve(wdir, './WebServer/ClientApp/dist')
  const stockFrontendBackup = path.resolve(frontendDir, 'main-C3O3U4EC.js.stock')
  const pkgPath = path.resolve(wdir, '../package.json')
  let frontendPatched = false

  const atomicWrite = (filePath, content) => {
    const buf = Buffer.isBuffer(content) ? content : Buffer.from(content, 'utf8')
    const tmp = filePath + '.tmp'
    fs.writeFileSync(tmp, buf)
    fs.renameSync(tmp, filePath)
    return buf
  }

  const getMainBundlePath = () => {
    const index = fs.readFileSync(path.resolve(frontendDir, 'index.html')).toString()
    const match = index.match(/main[^"']*?\.js/)
    if (!match) return null
    return path.resolve(frontendDir, match[0])
  }

  const ensureStockFrontendBackup = () => {
    const mainPath = getMainBundlePath()
    if (!mainPath) return null
    if (!fs.existsSync(stockFrontendBackup)) {
      const cur = fs.readFileSync(mainPath)
      if (!cur.includes('127.0.0.1:5678') && !cur.includes('getfiddler.com.localhost')) {
        fs.writeFileSync(stockFrontendBackup, cur)
        console.info('Created stock frontend backup', stockFrontendBackup, cur.length)
      }
    }
    return mainPath
  }

  const writePackageMain = (mainValue) => {
    try {
      const raw = fs.readFileSync(pkgPath, 'utf8')
      let next
      if (/"main"\s*:\s*"[^"]+"/.test(raw)) next = raw.replace(/"main"\s*:\s*"[^"]+"/, `"main": "${mainValue}"`)
      else {
        const data = JSON.parse(raw); data.main = mainValue; next = JSON.stringify(data, null, 4) + '\n'
      }
      atomicWrite(pkgPath, next)
      console.info('package.json main ->', mainValue)
    } catch (e) { console.error('writePackageMain failed', e) }
  }

  const restoreStockFrontend = () => {
    const mainPath = ensureStockFrontendBackup()
    if (!mainPath || !fs.existsSync(stockFrontendBackup)) return
    atomicWrite(mainPath, fs.readFileSync(stockFrontendBackup))
    frontendPatched = false
    console.info('Restored stock frontend', mainPath)
  }

  const patchFrontendToMock = () => {
    if (frontendPatched) { console.info('Frontend already patched, skip'); return }
    const mainPath = ensureStockFrontendBackup()
    if (!mainPath) return
    let text = fs.existsSync(stockFrontendBackup)
      ? fs.readFileSync(stockFrontendBackup, 'utf8')
      : fs.readFileSync(mainPath, 'utf8')

    // TFIS (Angular oauth) can stay path-style on 127.0.0.1
    const prodTfis = 'identityServiceBaseUrl:"https://identity.getfiddler.com",fiddlerApiBaseUrl:"https://api.getfiddler.com",cookieName:"ssid",cookieSecure:!0,clientId:"uri:fiddler"'
    const mockTfis = 'identityServiceBaseUrl:"http://127.0.0.1:5678/identity.getfiddler.com",fiddlerApiBaseUrl:"http://127.0.0.1:5678/api.getfiddler.com",cookieName:"ssid",cookieSecure:!1,clientId:"uri:fiddler"'
    if (!text.includes(prodTfis)) { console.error('prod TFIS config not found'); return }
    text = text.replace(prodTfis, mockTfis)

    // .NET BackendConfiguration rejects 127.0.0.1 host. Use *.getfiddler.com.localhost which resolves to loopback and contains getfiddler.com.
    const prodBackend = '_Ie={downloadsUrl:EG(["https://","downloads",".get","fiddler",".com"]),backendApiUrl:EG(["https://","api",".get","fiddler",".com"]),autoUpdateApiUrl:EG(["https://","api",".get","fiddler",".com"]),identityUrl:EG(["https://","identity",".get","fiddler",".com"]),telerikSiteUrl:"https://www.telerik.com",telerikIdentity:"https://identity.telerik.com",loginUrl:EG(["https://","get","fiddler",".com"]),docsSiteUrl:"https://www.telerik.com",cleverTapId:"696-565-785Z",userDirSuffix:"pd",qualarooScript:"https://cl.qualaroo.com/ki.js/24100/jqo.js"}'
    const mockBackend = '_Ie={downloadsUrl:"http://downloads.getfiddler.com.localhost:5678",backendApiUrl:"http://api.getfiddler.com.localhost:5678",autoUpdateApiUrl:"http://api.getfiddler.com.localhost:5678",identityUrl:"http://identity.getfiddler.com.localhost:5678",telerikSiteUrl:"https://www.telerik.com",telerikIdentity:"https://identity.telerik.com",loginUrl:"http://getfiddler.com.localhost:5678",docsSiteUrl:"https://www.telerik.com",cleverTapId:"696-565-785Z",userDirSuffix:"pd",qualarooScript:"https://cl.qualaroo.com/ki.js/24100/jqo.js"}'
    if (!text.includes(prodBackend)) { console.error('prod backendConfiguration object not found'); return }
    text = text.replace(prodBackend, mockBackend)

    const verifyNeedle = 'verifyData(n,e,t){let s=n.slice(0,e),o=new Uint8Array(new ArrayBuffer(s.length));if(o.set(s),!qj2().some(g=>g.length===o.length&&g.every((C,S)=>C===o[S])))return Promise.resolve(!1);let a=n.slice(e),p=new Uint8Array(new ArrayBuffer(a.length));return p.set(a),crypto.subtle.importKey("spki",o,{name:"ECDSA",namedCurve:"P-256"},!0,["verify"]).then(g=>crypto.subtle.verify({name:"ECDSA",hash:"SHA-256"},g,p,t))}'
    const verifyPatch = 'verifyData(n,e,t){return Promise.resolve(!0)}'
    if (text.includes(verifyNeedle)) {
      text = text.replace(verifyNeedle, verifyPatch)
      console.info('Applied exact verifyData patch')
    } else if (text.includes('verifyData(n,e,t){')) {
      text = text.replace(/verifyData\(n,e,t\)\{[\s\S]*?static\{this\./, 'verifyData(n,e,t){return Promise.resolve(!0)}static{this.')
      console.info('Applied loose verifyData patch')
    } else {
      console.error('verifyData not found'); return
    }

    text = text.replace(
      'Cannot retrieve minimum supported version after login. Signing out the user."),this.authStateService.signOut(),this.connectivityErrorStatus.next({hasConnectivityIssues:!0,errorMessage:"Access to *.getfiddler.com is being blocked."}),null;',
      'Cannot retrieve minimum supported version after login, continue with mock."),null;'
    )

    atomicWrite(mainPath, text)
    frontendPatched = true
    console.info('Patched frontend mock+sigbypass+localhost-host', mainPath, text.length)
  }

  try { ensureStockFrontendBackup() } catch (e) { console.error(e) }

  const originalSpwan = sp.spawn
  sp.spawn = function(...args) {
    console.info('Call spwan:', args[0])
    const child = originalSpwan.apply(this, args)
    if (String(args[0] || '').includes('Fiddler.WebUi')) {
      // Keep package.main on enhance entry so restarts still load mock/prefix.
      try { writePackageMain('out/main.js') } catch (e) { console.error(e) }
      // Do not restore stock frontend here; loadURL will ensure mock patch.
      try {
        child.on('exit', (code, signal) => {
          console.error('Fiddler.WebUi exited', { code, signal })
        })
      } catch (e) {}
    }
    return child
  }

  app.on('quit', () => {
    console.info('Call quit.')
    try { writePackageMain('out/main.js') } catch (e) {}
    try { restoreStockFrontend() } catch (e) {}
  })

  const i18nPath = path.resolve(wdir, './translate-i18n.js')
  const i18nBound = new WeakSet()
  const i18nInflight = new WeakMap()

  const readI18nCode = () => {
    try {
      if (!fs.existsSync(i18nPath)) {
        console.warn('translate-i18n.js missing:', i18nPath)
        return null
      }
      return fs.readFileSync(i18nPath, 'utf8')
    } catch (e) {
      console.error('read translate-i18n.js failed', e)
      return null
    }
  }

  const injectI18n = async (webContents, reason) => {
    try {
      if (!webContents || webContents.isDestroyed()) return
      if (i18nInflight.get(webContents)) return i18nInflight.get(webContents)
      const code = readI18nCode()
      if (!code) return
      const job = (async () => {
        const status = await webContents.executeJavaScript(`(() => {
          if (window.__fiddlerI18nInstalled && typeof window.__fiddlerToggleLanguagePanel === 'function') return 'already'
          return 'install'
        })()`, true)
        if (status === 'already') {
          console.info('i18n already present via', reason)
          return
        }
        await webContents.executeJavaScript(code + '\n;window.__fiddlerI18nInstalled = true;\n', true)
        console.info('i18n injected via', reason)
      })()
      i18nInflight.set(webContents, job)
      try { await job } finally {
        if (i18nInflight.get(webContents) === job) i18nInflight.delete(webContents)
      }
    } catch (e) {
      console.error('i18n inject failed', reason, e)
    }
  }

  const bindI18nToWebContents = (webContents) => {
    if (!webContents || i18nBound.has(webContents)) return
    i18nBound.add(webContents)
    const tryInject = (reason) => injectI18n(webContents, reason)
    webContents.on('dom-ready', () => tryInject('dom-ready'))
    webContents.on('did-finish-load', () => tryInject('did-finish-load'))
    webContents.on('before-input-event', (event, input) => {
      try {
        if (input.key === 'F12' && input.type === 'keyUp') {
          webContents.toggleDevTools()
          return
        }
        const key = String(input.key || '').toLowerCase()
        const isToggle = (input.control || input.meta) && !input.alt && !input.shift && (key === 't' || input.code === 'KeyT')
        if (isToggle && (input.type === 'keyDown' || input.type === 'keyUp')) {
          // 主进程兜底：避免页面/快捷键吞掉 Ctrl/Cmd+T
          event.preventDefault()
          if (input.type === 'keyDown') {
            webContents.executeJavaScript(`(async () => {
              if (!window.__fiddlerToggleLanguagePanel) {
                window.__fiddlerI18nInstalled = false
              }
              if (typeof window.__fiddlerToggleLanguagePanel === 'function') {
                window.__fiddlerToggleLanguagePanel()
                return 'toggled'
              }
              return 'missing'
            })()`, true).then((r) => {
              console.info('language toggle via main before-input:', r)
              if (r === 'missing') tryInject('before-input-missing')
            }).catch((e) => console.error('language toggle failed', e))
          }
        }
      } catch (e) {
        console.error('before-input i18n hook failed', e)
      }
    })
    webContents.on('console-message', (event, level, message, line, sourceId) => {
      console.info('renderer-console', level, message, `${sourceId}:${line}`)
    })
  }

  const originalBrowserWindow = BrowserWindow
  function HookedBrowserWindow(options) {
    try {
      if (options) {
        options.frame = false
        if (options.webPreferences) options.webPreferences.devTools = true
      }
      console.info('HookedBrowserWindow preload=', options && options.webPreferences && options.webPreferences.preload)
    } catch (e) {}
    const win = new originalBrowserWindow(options)
    try { bindI18nToWebContents(win.webContents) } catch (e) { console.error('bind i18n failed', e) }
    return win
  }
  HookedBrowserWindow.prototype = Object.create(originalBrowserWindow.prototype)
  HookedBrowserWindow.prototype.constructor = HookedBrowserWindow
  Object.setPrototypeOf(HookedBrowserWindow, originalBrowserWindow)
  const { Module } = require('module')
  const original_load = Module._load
  Module._load = (...args) => {
    const loaded = original_load(...args)
    if (args[0] === 'electron') return { ...loaded, BrowserWindow: HookedBrowserWindow }
    return loaded
  }

  const originloadURL = BrowserWindow.prototype.loadURL
  BrowserWindow.prototype.loadURL = function(...args) {
    try {
      this.setMinimumSize(300, 300)
      console.info('Call loadURL', args)
      bindI18nToWebContents(this.webContents)
      if (String(args[0] || '').includes('index.html')) patchFrontendToMock()
    } catch (e) { console.error('loadURL hook failed', e) }
    return originloadURL.apply(this, args)
  }
})();

// Server
(async () => {
  const http = require('http')
  const path = require('path')
  const fs = require('fs')
  const { subtle } = require('crypto').webcrypto
  const toWritable = (p) => String(p).replace(`${path.sep}app.asar${path.sep}`, `${path.sep}app.asar.unpacked${path.sep}`)
  const wdir = toWritable(__dirname)
  const key = await subtle.generateKey({ name: 'ECDSA', hash: 'SHA-256', namedCurve: 'P-256', length: 256 }, true, ['sign', 'verify'])
  const pubKey = await subtle.exportKey('spki', key.publicKey)
  const priKey = await subtle.exportKey('pkcs8', key.privateKey)

  const mapHostToPrefix = (hostHeader) => {
    if (!hostHeader) return null
    const host = String(hostHeader).split(':')[0].toLowerCase()
    // host-style: api.getfiddler.com.localhost -> api.getfiddler.com
    if (host.endsWith('.localhost')) {
      const base = host.slice(0, -'.localhost'.length)
      if (base.includes('getfiddler.com')) return base
    }
    if (host.includes('getfiddler.com')) return host
    return null
  }

  const sendJson = async (res, data) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8')
    const headers = { 'content-type': 'application/json; charset=utf-8' }
    const signData = Object.keys(headers).map(k => `${k}:${headers[k]}`).join('\n') + data
    const signPriKey = await subtle.importKey('pkcs8', priKey, { name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign'])
    const signature = await subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, signPriKey, Buffer.from(signData, 'binary'))
    const len = Buffer.alloc(4); len.writeInt32BE(pubKey.byteLength)
    const signatureHeader = Buffer.concat([len, Buffer.from(pubKey), Buffer.from(signature)])
    res.setHeader('Signature', `SignedHeaders=content-type, Signature=${signatureHeader.toString('base64')}`)
    res.end(data)
  }

  const handler = async (req, res) => {
    try {
      const url = new URL(req.url, `http://127.0.0.1:${port}`)
      console.log(req.method, req.headers.host, url.pathname)
      let rel = url.pathname.replace(/^\/+/, '').split('?')[0]
      const hostPrefix = mapHostToPrefix(req.headers.host)
      // If path-style already has api.getfiddler.com/..., keep it.
      // If host-style (api.getfiddler.com.localhost/users), prefix host base.
      if (hostPrefix && !rel.startsWith('api.getfiddler.com') && !rel.startsWith('identity.getfiddler.com') && !rel.startsWith('downloads.getfiddler.com') && !rel.startsWith('getfiddler.com')) {
        rel = `${hostPrefix}/${rel}`.replace(/\/+$/, '').replace(/\/{2,}/g, '/')
      }
      if (rel.startsWith('identity.getfiddler.com/signout')) { res.end('ok'); return }
      if (rel.startsWith('api.getfiddler.com/c/') && rel.endsWith('.yml')) {
        res.setHeader('Content-Type', 'text/yaml')
        res.end('version: 8.0.1\nfiles: []\npath: Fiddler Everywhere-8.0.1.dmg\nsha512: dummy\nreleaseDate: 2026-01-01T00:00:00.000Z\n')
        return
      }
      // login redirect landing for authorize iframe style
      if (rel === '' || rel === '/') {
        // authorize callback sometimes hits root with ?code=
        res.end('ok'); return
      }
      const loc = path.resolve(wdir, 'file', rel)
      if (fs.existsSync(loc + '.json')) {
        await sendJson(res, fs.readFileSync(loc + '.json').toString())
        return
      }
      if (fs.existsSync(loc) && fs.statSync(loc).isFile()) {
        res.end(fs.readFileSync(loc)); return
      }
      console.log('error: not implement', rel, '->', loc)
      if (rel.includes('oauth') || rel.includes('users') || rel.includes('versions') || rel.endsWith('.json')) {
        await sendJson(res, '{}')
      } else {
        res.end('not implement')
      }
    } catch (e) {
      console.error(e)
      res.statusCode = 500
      res.end('error')
    }
  }

  // dual-stack: IPv6 :: (covers *.localhost -> ::1) and IPv4 0.0.0.0
  const server6 = http.createServer(handler)
  server6.on('error', (e) => console.error('Mock IPv6 server error', e))
  server6.listen(port, '::', () => console.info('Mock auth server listening on [::]:' + port, 'root', path.resolve(wdir, 'file')))
  // if ipv4 separate needed and not shared:
  try {
    const server4 = http.createServer(handler)
    server4.on('error', (e) => console.warn('IPv4 mock listen skip', e && e.code))
    server4.listen(port, '0.0.0.0', () => console.info('Mock auth server listening on 0.0.0.0:' + port))
  } catch (e) { console.warn(e) }
})();

