param(
  [string]$Root = "",
  [switch]$SkipKill
)
$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Py = Get-Command python -ErrorAction SilentlyContinue
if (-not $Py) { $Py = Get-Command python3 -ErrorAction SilentlyContinue }
if (-not $Py) { throw "Python not found. Install Python 3 and retry." }

$argsList = @("$ScriptDir\clean_patch_8.0.1_windows.py")
if ($Root) { $argsList += @("--root", $Root) }
if ($SkipKill) { $argsList += "--skip-kill" }

Write-Host "Running:" $Py.Source $argsList
& $Py.Source @argsList
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host ""
Write-Host "Patch finished."
Write-Host "Launch Fiddler Everywhere and click Sign in."
Write-Host "Language: Ctrl+T"
