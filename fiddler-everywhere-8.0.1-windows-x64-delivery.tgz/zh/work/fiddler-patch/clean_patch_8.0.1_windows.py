#!/usr/bin/env python3
"""Clean patch for Fiddler Everywhere 8.0.1 Windows x64 (CTF/lab).

Reuse the verified Mac 8.0.1 logic:
- Yui fiddler.dll
- enhance main prefix + mock backend
- frontend host-style mock endpoints
- FiddlerBackendSDK / Fiddler.WebUi binary patches
- translate-i18n.js injection (Ctrl+T)

Does NOT overwrite official preload.js.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
DEBUG = WORK / "fiddler-debug"
ENHANCE_REPO = WORK / "fiddler-everywhere-enhance"
PREFIX = DEBUG / "enhance_prefix_current.js"
I18N = DEBUG / "translate-i18n.js"
STOCK_MAIN = HERE / "backup-stock-8.0.1/main.js"
STOCK_ASAR = DEBUG / "app.asar.stock"
FE_STOCK_FALLBACK = DEBUG / "frontend_stock_restored.js"
SDK_STOCK = HERE / "backup-stock-8.0.1/FiddlerBackendSDK.dll"
WEBUI_STOCK = HERE / "backup-stock-8.0.1/Fiddler.WebUi.dll"
SDK_PATCHED_COPY = HERE / "FiddlerBackendSDK.patched.dll"
WEBUI_PATCHED_COPY = HERE / "Fiddler.WebUi.patched.dll"
YUI_CANDIDATES = [
    HERE / "yui-fiddler-win32-x86_64-v1.1.4.dll",
    HERE / "yui-fiddler-win32-x86_64-v1.1.3.dll",
    HERE / "fiddler.dll",
]


def sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def pe_rva_to_off(data: bytes, rva: int) -> int:
    if data[:2] != b"MZ":
        raise ValueError("not PE")
    e_lfanew = int.from_bytes(data[0x3C:0x40], "little")
    if data[e_lfanew:e_lfanew + 4] != b"PE\0\0":
        raise ValueError("bad PE")
    coff = e_lfanew + 4
    num_sections = int.from_bytes(data[coff + 2:coff + 4], "little")
    size_opt = int.from_bytes(data[coff + 16:coff + 18], "little")
    sec_off = coff + 20 + size_opt
    for i in range(num_sections):
        s = sec_off + i * 40
        va = int.from_bytes(data[s + 12:s + 16], "little")
        vsz = int.from_bytes(data[s + 8:s + 12], "little")
        raw = int.from_bytes(data[s + 20:s + 24], "little")
        if va <= rva < va + max(vsz, 1):
            return raw + (rva - va)
    raise ValueError(f"rva not found: {rva:#x}")


def patch_method(data: bytearray, rva: int, body: bytes, maxstack: int = 8) -> None:
    off = pe_rva_to_off(data, rva)
    if data[off] & 3 != 3:
        raise ValueError(f"expected fat method at {rva:#x}")
    old_cs = int.from_bytes(data[off + 4:off + 8], "little")
    data[off:off + 2] = (0x3013).to_bytes(2, "little")
    data[off + 2:off + 4] = int(maxstack).to_bytes(2, "little")
    data[off + 4:off + 8] = len(body).to_bytes(4, "little")
    data[off + 8:off + 12] = (0).to_bytes(4, "little")
    body_off = off + 12
    for i in range(min(old_cs, 1024)):
        data[body_off + i] = 0
    data[body_off:body_off + len(body)] = body
    print(f"method rva={rva:#x} off={off:#x} cs={len(body)} body={body.hex()}")


def integrity_for(buf: bytes, block_size: int = 4194304) -> dict:
    blocks = [sha256(buf[i:i + block_size]) for i in range(0, len(buf), block_size)] or [sha256(b"")]
    return {"algorithm": "SHA256", "hash": sha256(buf), "blockSize": block_size, "blocks": blocks}


def kill_fiddler() -> None:
    names = [
        "Fiddler Everywhere.exe",
        "Fiddler.WebUi.exe",
        "Fiddler Everywhere",
        "Fiddler.WebUi",
    ]
    if os.name == "nt":
        for n in names:
            subprocess.run(["taskkill", "/F", "/IM", n], capture_output=True, text=True)
    else:
        for n in ["Fiddler Everywhere", "Fiddler.WebUi", "Fiddler Everywhere.exe"]:
            subprocess.run(["pkill", "-9", "-f", n], check=False)
    time.sleep(1)


def default_roots() -> list[Path]:
    roots: list[Path] = []
    env = os.environ.get("FIDDLER_EVERYWHERE_ROOT") or os.environ.get("FIDDLER_ROOT")
    if env:
        roots.append(Path(env))
    local = os.environ.get("LOCALAPPDATA")
    pf = os.environ.get("ProgramFiles")
    pf86 = os.environ.get("ProgramFiles(x86)")
    for base in [local, pf, pf86]:
        if not base:
            continue
        roots.append(Path(base) / "Programs" / "Fiddler Everywhere")
        roots.append(Path(base) / "Fiddler Everywhere")
    # common portable / custom
    roots.extend([
        Path.cwd() / "Fiddler Everywhere",
        Path.cwd() / "FiddlerEverywhere",
        Path("C:/Users") / os.environ.get("USERNAME", "") / "AppData/Local/Programs/Fiddler Everywhere",
    ])
    # dedupe keep order
    seen = set()
    out = []
    for r in roots:
        key = str(r).lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def resolve_root(cli_root: str | None) -> Path:
    if cli_root:
        p = Path(cli_root).expanduser().resolve()
        if not p.exists():
            raise FileNotFoundError(p)
        return p
    for r in default_roots():
        if (r / "resources").exists() or (r / "Fiddler Everywhere.exe").exists() or (r / "fiddler.dll").exists():
            return r.resolve()
    raise FileNotFoundError(
        "Cannot auto-detect Fiddler Everywhere install root. "
        "Pass --root \"C:\\\\Path\\\\To\\\\Fiddler Everywhere\""
    )


def resolve_layout(root: Path) -> dict[str, Path]:
    res = root / "resources"
    if not res.exists():
        # some portable layouts put resources next to exe under different casing
        for c in root.iterdir() if root.exists() else []:
            if c.name.lower() == "resources":
                res = c
                break
    unp = res / "app.asar.unpacked"
    app_dir = res / "app"
    # prefer unpacked if present, else app dir
    if unp.exists():
        base = unp
    elif app_dir.exists():
        base = app_dir
    else:
        base = unp
        base.mkdir(parents=True, exist_ok=True)
    out = base / "out"
    return {
        "root": root,
        "res": res,
        "unp": base,
        "out": out,
        "asar": res / "app.asar",
        "pkg": base / "package.json",
        "sdk": out / "WebServer" / "FiddlerBackendSDK.dll",
        "webui": out / "WebServer" / "Fiddler.WebUi.dll",
        "preload": out / "services" / "lib" / "preload.js",
        "frontend_dir": out / "WebServer" / "ClientApp" / "dist",
    }


def update_asar(asar_path: Path, updates: dict[str, bytes]) -> None:
    if not asar_path.exists():
        print("skip asar update: missing", asar_path)
        return
    data = asar_path.read_bytes()
    js = data.find(b'{"files"')
    if js < 0:
        print("skip asar update: header not found")
        return
    header, end = json.JSONDecoder().raw_decode(data[js:].decode())
    json_end = js + end
    for rel, buf in updates.items():
        node = header
        try:
            for part in rel.split("/"):
                node = node["files"][part]
        except KeyError:
            print("asar path missing, skip:", rel)
            continue
        node["size"] = len(buf)
        node["unpacked"] = True
        node["integrity"] = integrity_for(buf, (node.get("integrity") or {}).get("blockSize", 4194304))
        print("asar", rel, node["integrity"]["hash"][:16], len(buf))
    new_json = json.dumps(header, separators=(",", ":"), ensure_ascii=False).encode()
    json_len = len(new_json)
    new_base = ((16 + json_len + 3) // 4) * 4
    head = bytearray(new_base)
    struct.pack_into("<IIII", head, 0, 4, ((json_len + 3) // 4 * 4) + 8, json_len + 4, json_len)
    head[16:16 + json_len] = new_json
    old_base = ((json_end + 3) // 4) * 4
    tmp = asar_path.with_suffix(".asar.tmp")
    tmp.write_bytes(bytes(head) + data[old_base:])
    tmp.replace(asar_path)
    print("updated", asar_path)


def extract_packed(asar_path: Path, unp: Path) -> None:
    if not asar_path.exists():
        print("no app.asar to extract")
        return
    data = asar_path.read_bytes()
    js = data.find(b'{"files"')
    header, end = json.JSONDecoder().raw_decode(data[js:].decode())
    content_base = ((js + end + 3) // 4) * 4

    def walk(d, prefix=""):
        for k, v in d.items():
            p = f"{prefix}/{k}" if prefix else k
            if "files" in v:
                yield from walk(v["files"], p)
            else:
                yield p, v

    for p, n in walk(header["files"]):
        if n.get("unpacked"):
            continue
        dest = unp / p
        dest.parent.mkdir(parents=True, exist_ok=True)
        off = int(n["offset"])
        dest.write_bytes(data[content_base + off: content_base + off + n["size"]])
        print("extract", p, n["size"])


def pick_yui() -> Path:
    for p in YUI_CANDIDATES:
        if p.exists():
            return p
    raise FileNotFoundError("missing Yui Windows dll, expected yui-fiddler-win32-x86_64-v1.1.4.dll")


def deploy_yui(root: Path, yui: Path) -> None:
    # 5.17+ uses fiddler.dll at install root; older uses libfiddler.dll
    for name in ("fiddler.dll", "libfiddler.dll"):
        dst = root / name
        shutil.copy2(yui, dst)
        print("deployed", dst, "from", yui.name)


def deploy_mock(out: Path) -> Path:
    mock_src = ENHANCE_REPO / "server" / "file"
    mock_dst = out / "file"
    if mock_dst.exists():
        shutil.rmtree(mock_dst)
    shutil.copytree(mock_src, mock_dst)

    tok_path = mock_dst / "identity.getfiddler.com/oauth/token.json"
    tok = json.loads(tok_path.read_text(encoding="utf-8"))
    tok.setdefault("refresh_token", tok.get("id_token"))
    tok.setdefault("access_token", tok.get("id_token"))
    tok["expires_in"] = max(int(tok.get("expires_in") or 0), 315360000)
    tok_path.write_text(json.dumps(tok, indent=2) + "\n", encoding="utf-8")

    jwks = {
        "keys": [{
            "kty": "EC", "crv": "P-256",
            "x": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            "y": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            "kid": "58068943-cebb-4659-b66d-fff69586705d",
            "use": "sig", "alg": "ES256"
        }]
    }
    (mock_dst / "identity.getfiddler.com/oauth/jwks.json").write_text(json.dumps(jwks, indent=2) + "\n", encoding="utf-8")
    (mock_dst / "identity.getfiddler.com/signout").write_text("ok\n", encoding="utf-8")

    ver_path = mock_dst / "api.getfiddler.com/versions.json"
    ver = json.loads(ver_path.read_text(encoding="utf-8"))
    ver["everywhereMinVersionSupported"] = "0.0.1"
    ver["version"] = "8.0.1"
    ver_path.write_text(json.dumps(ver, indent=2) + "\n", encoding="utf-8")

    for rel in ["api.getfiddler.com/users.json", "api.getfiddler.com/users/sign-in.json"]:
        data = json.loads((mock_dst / rel).read_text(encoding="utf-8"))
        for acc in data.get("accounts", []):
            acc["licenseIsCancelled"] = False
        (mock_dst / rel).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print("deployed mock", mock_dst)
    return mock_dst


def patch_backend_sdk(sdk_path: Path) -> None:
    if not SDK_STOCK.exists():
        if not sdk_path.exists():
            raise FileNotFoundError(sdk_path)
        SDK_STOCK.parent.mkdir(parents=True, exist_ok=True)
        SDK_STOCK.write_bytes(sdk_path.read_bytes())
        print("backed up stock SDK", SDK_STOCK)
    data = bytearray(SDK_STOCK.read_bytes())
    patch_method(data, 0x2928, bytes([0x02, 0x03, 0x7D, 0x13, 0x00, 0x00, 0x04, 0x2A]))
    patch_method(data, 0x2abc, bytes([0x02, 0x03, 0x7D, 0x14, 0x00, 0x00, 0x04, 0x2A]))
    patch_method(data, 0x14408, bytes([0x02, 0x03, 0x04, 0x28, 0x95, 0x04, 0x00, 0x0A, 0x2A]))
    patch_method(data, 0x1473c, bytes([0x17, 0x2A]), maxstack=1)
    patch_method(data, 0x5b78, bytes([0x17, 0x2A]), maxstack=1)
    sdk_path.parent.mkdir(parents=True, exist_ok=True)
    sdk_path.write_bytes(data)
    SDK_PATCHED_COPY.write_bytes(data)
    print("patched", sdk_path, "sha256", sha256(bytes(data))[:16])


def patch_webui_integrity(webui_path: Path) -> None:
    if not WEBUI_STOCK.exists():
        if not webui_path.exists():
            raise FileNotFoundError(webui_path)
        WEBUI_STOCK.parent.mkdir(parents=True, exist_ok=True)
        WEBUI_STOCK.write_bytes(webui_path.read_bytes())
        print("backed up stock WebUi", WEBUI_STOCK)
    data = bytearray(WEBUI_STOCK.read_bytes())
    for rva in (0xB16E8, 0xB2058):
        patch_method(data, rva, bytes([0x17, 0x2A]), maxstack=1)
    patch_method(data, 0x2500C, bytes([0x28, 0x98, 0x00, 0x00, 0x0A, 0x2A]), maxstack=1)
    webui_path.parent.mkdir(parents=True, exist_ok=True)
    webui_path.write_bytes(data)
    WEBUI_PATCHED_COPY.write_bytes(data)
    print("patched", webui_path, "sha256", sha256(bytes(data))[:16])


def find_frontend_bundle(frontend_dir: Path) -> Path:
    index = frontend_dir / "index.html"
    if index.exists():
        m = re.search(r"main[^\"']*?\.js", index.read_text(encoding="utf-8", errors="ignore"))
        if m:
            p = frontend_dir / m.group(0)
            if p.exists():
                return p
    cands = sorted(frontend_dir.glob("main-*.js"))
    if cands:
        return cands[0]
    raise FileNotFoundError(f"frontend main bundle not found under {frontend_dir}")


def ensure_frontend_stock(fe: Path) -> Path:
    stock = Path(str(fe) + ".stock")
    if stock.exists() and b"127.0.0.1:5678" not in stock.read_bytes() and b"getfiddler.com.localhost" not in stock.read_bytes():
        return stock
    if fe.exists() and b"127.0.0.1:5678" not in fe.read_bytes() and b"getfiddler.com.localhost" not in fe.read_bytes():
        stock.write_bytes(fe.read_bytes())
        print("created frontend stock", stock)
        return stock
    if FE_STOCK_FALLBACK.exists():
        stock.write_bytes(FE_STOCK_FALLBACK.read_bytes())
        print("used frontend fallback stock", FE_STOCK_FALLBACK)
        return stock
    raise FileNotFoundError("no clean frontend stock available")


def patch_frontend_text(text: str) -> str:
    prod_tfis = 'identityServiceBaseUrl:"https://identity.getfiddler.com",fiddlerApiBaseUrl:"https://api.getfiddler.com",cookieName:"ssid",cookieSecure:!0,clientId:"uri:fiddler"'
    mock_tfis = 'identityServiceBaseUrl:"http://127.0.0.1:5678/identity.getfiddler.com",fiddlerApiBaseUrl:"http://127.0.0.1:5678/api.getfiddler.com",cookieName:"ssid",cookieSecure:!1,clientId:"uri:fiddler"'
    if prod_tfis not in text:
        raise RuntimeError("prod TFIS config not found in frontend")
    text = text.replace(prod_tfis, mock_tfis)

    prod_backend = '_Ie={downloadsUrl:EG(["https://","downloads",".get","fiddler",".com"]),backendApiUrl:EG(["https://","api",".get","fiddler",".com"]),autoUpdateApiUrl:EG(["https://","api",".get","fiddler",".com"]),identityUrl:EG(["https://","identity",".get","fiddler",".com"]),telerikSiteUrl:"https://www.telerik.com",telerikIdentity:"https://identity.telerik.com",loginUrl:EG(["https://","get","fiddler",".com"]),docsSiteUrl:"https://www.telerik.com",cleverTapId:"696-565-785Z",userDirSuffix:"pd",qualarooScript:"https://cl.qualaroo.com/ki.js/24100/jqo.js"}'
    mock_backend = '_Ie={downloadsUrl:"http://downloads.getfiddler.com.localhost:5678",backendApiUrl:"http://api.getfiddler.com.localhost:5678",autoUpdateApiUrl:"http://api.getfiddler.com.localhost:5678",identityUrl:"http://identity.getfiddler.com.localhost:5678",telerikSiteUrl:"https://www.telerik.com",telerikIdentity:"https://identity.telerik.com",loginUrl:"http://getfiddler.com.localhost:5678",docsSiteUrl:"https://www.telerik.com",cleverTapId:"696-565-785Z",userDirSuffix:"pd",qualarooScript:"https://cl.qualaroo.com/ki.js/24100/jqo.js"}'
    if prod_backend not in text:
        raise RuntimeError("prod backendConfiguration object not found in frontend")
    text = text.replace(prod_backend, mock_backend)

    verify_needle = 'verifyData(n,e,t){let s=n.slice(0,e),o=new Uint8Array(new ArrayBuffer(s.length));if(o.set(s),!qj2().some(g=>g.length===o.length&&g.every((C,S)=>C===o[S])))return Promise.resolve(!1);let a=n.slice(e),p=new Uint8Array(new ArrayBuffer(a.length));return p.set(a),crypto.subtle.importKey("spki",o,{name:"ECDSA",namedCurve:"P-256"},!0,["verify"]).then(g=>crypto.subtle.verify({name:"ECDSA",hash:"SHA-256"},g,p,t))}'
    verify_repl = 'verifyData(n,e,t){return Promise.resolve(!0)}'
    if verify_needle in text:
        text = text.replace(verify_needle, verify_repl)
    else:
        # softer fallback
        text2, n = re.subn(r"verifyData\([^)]*\)\{", "verifyData(n,e,t){return Promise.resolve(!0)}/*", text, count=1)
        if n:
            text = text2
            print("frontend verifyData soft-patched")
        else:
            print("WARN: verifyData pattern not found")
    return text


def prepare_main_js(out: Path) -> bytes:
    stock_src = STOCK_MAIN if STOCK_MAIN.exists() else (out / "main.js")
    if not stock_src.exists():
        raise FileNotFoundError("main.js stock missing")
    stock_main = stock_src.read_text(encoding="utf-8", errors="ignore")
    # if current main already has enhance prefix, prefer pure stock backup
    if "Fiddler-everywhere-enhance start" in stock_main and STOCK_MAIN.exists():
        stock_main = STOCK_MAIN.read_text(encoding="utf-8", errors="ignore")

    old_h2 = 'function h2(e){try{let t=new URL(e);return t.protocol!=="https:"||t.port!==""?!1:M6t.some(r=>t.hostname===r||t.hostname.endsWith("."+r))}catch{return!1}}'
    new_h2 = 'function h2(e){try{let t=new URL(e);const h=t.hostname;if(h==="127.0.0.1"||h==="localhost"||h.endsWith(".localhost")||h.includes("getfiddler.com"))return!0;return t.protocol!=="https:"||t.port!==""?!1:M6t.some(r=>h===r||h.endsWith("."+r))}catch{return!1}}'
    if old_h2 in stock_main:
        stock_main = stock_main.replace(old_h2, new_h2)
        print("patched main h2 allowlist")
    else:
        print("WARN: h2 pattern missing (Windows build may differ); continue")

    old_crash = "this.handleServerCrash=t=>{this.logger.info(`The server process has crashed with code '${t}' - quitting the app`),this.currentServerProcess.removeListener(\"close\",this.handleServerCrash),Uu.dialog.showErrorBox(\"Fiddler Everywhere\",\"An unexpected error occurred. Sorry for the inconvenience, please restart the application. If the problem persists, please contact support.\"),Uu.app.exit()}"
    new_crash = "this.handleServerCrash=t=>{this.logger.info(`The server process has crashed with code '${t}' - attempting restart`),this.currentServerProcess&&this.currentServerProcess.removeListener(\"close\",this.handleServerCrash),this.currentServerProcess=null,this.startServer().catch(r=>{this.logger.error(\"Failed to restart server after crash\",r),Uu.dialog.showErrorBox(\"Fiddler Everywhere\",\"An unexpected error occurred. Sorry for the inconvenience, please restart the application. If the problem persists, please contact support.\"),Uu.app.exit()})}"
    if old_crash in stock_main:
        stock_main = stock_main.replace(old_crash, new_crash)
        print("patched server crash auto-restart")
    else:
        print("WARN: handleServerCrash pattern missing; continue")

    prefix = PREFIX.read_text(encoding="utf-8")
    (out / "main.original.js").write_text(stock_main if "Fiddler-everywhere-enhance start" not in stock_main else STOCK_MAIN.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")
    main_js = prefix + "\n" + stock_main
    (out / "main.js").write_text(main_js, encoding="utf-8")
    print("wrote", out / "main.js", len(main_js))
    return main_js.encode("utf-8")


def write_package_main(pkg_path: Path) -> bytes:
    if pkg_path.exists():
        raw = pkg_path.read_text(encoding="utf-8")
        try:
            pkg = json.loads(raw)
        except Exception:
            pkg = {}
    else:
        pkg = {"name": "fiddler-everywhere", "version": "8.0.1"}
    pkg["main"] = "out/main.js"
    text = json.dumps(pkg, indent=4) + "\n"
    pkg_path.write_text(text, encoding="utf-8")
    print("package.json main -> out/main.js")
    return text.encode("utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description="Patch Fiddler Everywhere 8.0.1 for Windows x64")
    ap.add_argument("--root", help="Install root of Fiddler Everywhere")
    ap.add_argument("--skip-kill", action="store_true")
    ap.add_argument("--skip-asar-extract", action="store_true")
    args = ap.parse_args()

    required = [PREFIX, I18N, ENHANCE_REPO / "server/file", SDK_STOCK, WEBUI_STOCK]
    for p in required:
        if not Path(p).exists():
            print("missing", p, file=sys.stderr)
            return 1
    yui = pick_yui()

    try:
        root = resolve_root(args.root)
    except Exception as e:
        print(e, file=sys.stderr)
        return 1
    layout = resolve_layout(root)
    print("root =", layout["root"])
    print("out  =", layout["out"])

    if not args.skip_kill:
        kill_fiddler()

    # optional restore stock asar if we have one and target asar exists
    if STOCK_ASAR.exists() and layout["asar"].exists():
        # only restore when asar looks tiny/header-only integrity style or user wants clean
        # keep current asar by default on Windows to avoid wiping unknown build; extract missing preload if needed
        pass

    if not args.skip_asar_extract and layout["asar"].exists() and not layout["preload"].exists():
        extract_packed(layout["asar"], layout["unp"])

    layout["out"].mkdir(parents=True, exist_ok=True)
    deploy_yui(layout["root"], yui)
    deploy_mock(layout["out"])
    shutil.copy2(I18N, layout["out"] / "translate-i18n.js")
    print("deployed", layout["out"] / "translate-i18n.js")

    # ensure preload exists; do not overwrite
    if not layout["preload"].exists():
        print("WARN: official preload.js missing:", layout["preload"])
        print("If app whitescreens, reinstall official 8.0.1 and rerun.")

    patch_backend_sdk(layout["sdk"])
    patch_webui_integrity(layout["webui"])

    # frontend
    fe = find_frontend_bundle(layout["frontend_dir"])
    fe_stock = ensure_frontend_stock(fe)
    fe_text = patch_frontend_text(fe_stock.read_text(encoding="utf-8", errors="ignore"))
    fe.write_text(fe_text, encoding="utf-8")
    print("patched frontend", fe, "sha256", sha256(fe.read_bytes())[:16])

    # if target main is already patched from a different source, still rewrite from stock/prefix
    if not STOCK_MAIN.exists() and (layout["out"] / "main.js").exists():
        # backup once
        bak = layout["out"] / "main.js.before-windows-patch"
        if not bak.exists():
            shutil.copy2(layout["out"] / "main.js", bak)
    main_bytes = prepare_main_js(layout["out"])
    pkg_bytes = write_package_main(layout["pkg"])

    # asar integrity for known files when present
    rel_fe = "out/WebServer/ClientApp/dist/" + fe.name
    update_asar(layout["asar"], {
        "out/main.js": main_bytes,
        rel_fe: fe.read_bytes(),
        "package.json": pkg_bytes,
    })

    print("\nDONE")
    print("Start Fiddler Everywhere, then Sign in.")
    print("Language toggle: Ctrl+T")
    print("Mock check: http://api.getfiddler.com.localhost:5678/versions")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
